</div>
		</section>
		<footer>
			<div class="conteneur">
				<?php echo date('Y') ?> - Tous droits reservés
			</div>
		</footer>
	</body>
</html>