<?php
header('Content-type: application/json');
   ?>
   {
      "result": "<?php print_r($_POST);?>" // Ajouter avec succes
   }
